import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router';
import { rootRouterConfig } from './app.routes';
import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

import { ProfilesComponent } from './profiles/profiles.component';
import { HomeComponent } from './home/home.component';
import { NewsComponent } from './news/news.component';
import { GraphComponent } from './graph/graph.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { ContactComponent } from './contact/contact.component';

@NgModule({
  declarations: [
    AppComponent,
    ProfilesComponent,
    NewsComponent,
    GraphComponent,
    HomeComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(rootRouterConfig, { useHash: true })
  ],
  // providers: [
  //   GithubService
  // ],
  bootstrap: [ AppComponent ]
})
export class AppModule {

}
