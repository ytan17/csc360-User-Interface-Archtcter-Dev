import {Component} from '@angular/core';

@Component({
  selector: 'profiles',
  styleUrls: ['./profiles.component.css'],
  templateUrl: './profiles.component.html'
})
export class ProfilesComponent {
}
