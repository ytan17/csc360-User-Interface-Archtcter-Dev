import {Component} from '@angular/core';

@Component({
  selector: 'graph',
  styleUrls: ['./graph.component.css'],
  templateUrl: './graph.component.html'
})
export class GraphComponent {
}
