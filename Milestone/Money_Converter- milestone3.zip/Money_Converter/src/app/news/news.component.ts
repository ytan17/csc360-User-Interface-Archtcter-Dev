import {Component} from '@angular/core';

@Component({
  selector: 'news',
  styleUrls: ['./news.component.css'],
  templateUrl: './news.component.html'
})
export class NewsComponent {
}